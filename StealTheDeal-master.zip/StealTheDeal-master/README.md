# StealTheDeal
An android app.
This app provides details of deals which are available in firebase-database. Other than that fragments are used. Login, logout, regiter, change password, map activity, everyhing is working.

This android app is made by me for my android project. Later I decided to put it on github for laerning purpose to others.

I have used custom list vew, splash activity and firbase data connectivity.
App is built for API 26(Marshmallow) and above.
Gradle is used 4.0 and firebase modules versions are >=11.2.0

App requires internet with >=120 kbps spped.

NOTE: Update google.json with your firebase credentials for login and signup to be working.
